package com.cg.servlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDao {
	
	Connection con=null;
	PreparedStatement ps =null;
 public Connection getConnection()
 {
	 try{
		 Class.forName("oracle.jdbc.driver.OracleDriver");
		 String url= "jdbc:oracle:thin:@localhost:1521:XE";
		 String user = "system";
		 String pass ="Capgemini123";
		 con = DriverManager.getConnection(url,user,pass);
		 return con;
				 }catch(Exception e)
	 {
					 e.printStackTrace();
						
	 }return con;
 }	
	 public boolean validateuser(String username, String password) 
	{
		try{
		con=getConnection();
		String sql ="select * from user_details where username=?and password=?";
		ps=con.prepareStatement(sql);
		ps.setString(1, username);
		ps.setString(2,password);
		ResultSet rs=ps.executeQuery();
		//System.out.println(rs.getInt(1));
		return rs.next();
		}catch(Exception e){
			
		}return false;
	}
	
	
	 public int  add(String username,String password, String mail, String Phoneno) {
		try{
		  con =getConnection();
		  String sql="insert into user_details values(?,?,?,?)";
			  ps=con.prepareStatement(sql);
			  ps.setString(1, username);
			  ps.setString(2, password);
			  ps.setString(3, mail);
			  ps.setString(4,Phoneno);
			  int n=ps.executeUpdate();
			
			  return n;
		  }catch(Exception e) {
			  e.printStackTrace();
			  
		  }
		return 0;
	}
	 
	 

	 public int  adddetails(String pid,String pname, String pmodel, String price) {
		try{
		  con =getConnection();
		  String sql="insert into products values(?,?,?,?)";
			  ps=con.prepareStatement(sql);
			  ps.setString(1, pid);
			  ps.setString(2, pname);
			  ps.setString(3, pmodel);
			  ps.setString(4,price);
			  int n =ps.executeUpdate();
			  return n;
		  }catch(Exception e) {
			  e.printStackTrace();
			  
		  }
		return 0;
	}
	 
	 
	 
	 
	 public int  editdetails(String pid,String pname, String pmodel, String price) {
			try{
			  con =getConnection();
			  String sql="update products set PRICE=? WHERE PID=?";
				  ps=con.prepareStatement(sql);
				  ps.setString(1,price);
				  ps.setString(2, pid);
				  int n=ps.executeUpdate();
				  return n;
			  }catch(Exception e) {
				  e.printStackTrace();
				  return 0;
			  }
			
		}
	 
	 
	 public int  deletedetails(String pid) {
			try{
			  con =getConnection();
			  String sql="delete from products where pid=?";
				  ps=con.prepareStatement(sql);
				  ps.setString(1,pid);
				  int n =ps.executeUpdate();
				  return n;
			  }catch(Exception e) {
				  e.printStackTrace();
				  return 0;
			  }
			
		}
	 
	 
	 
	public int password(String username,String password,String confpassword){
		 try{		
			 
			 if(password.equals(confpassword))
			{
				System.out.println(password);
			  con =getConnection();
			  String sql="update user_details SET PASSWORD = ? WHERE USERNAME=?";
				  ps=con.prepareStatement(sql);
				  ps.setString(1,password);
				  ps.setString(2,username);
				 ps.executeUpdate();
				  return 1;
			 
			  }
		 }catch(Exception e) {
			  e.printStackTrace();
			 
			
} return 0;
	}
}
