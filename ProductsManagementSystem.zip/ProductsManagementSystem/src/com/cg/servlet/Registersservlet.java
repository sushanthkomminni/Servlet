package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class Registersservlet
 */
@WebServlet("/Registersservlet")
public class Registersservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		String mailid=request.getParameter("mail");
		String phonenumber=request.getParameter("phon");
		 UserDao dao=new UserDao();
		 int na=dao.add(username, password, mailid, phonenumber);
		 if(na>0)
		 {
			// response.sendRedirect("login.jsp");
			 RequestDispatcher rd= request.getRequestDispatcher("login.jsp?emsg=user registered successfully");
			 rd.forward(request, response);
		 }
		 else
		 {
		 
			 RequestDispatcher rd= request.getRequestDispatcher("register.jsp?emsg=something went wrong");
					 rd.include(request, response);
		 
	}
		 
	}

}
