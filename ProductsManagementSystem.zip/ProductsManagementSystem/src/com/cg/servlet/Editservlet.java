package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class Editservlet
 */
@WebServlet("/Editservlet")
public class Editservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String pid=request.getParameter("pid");
		String productname =request.getParameter("pname");
		String productmodel =request.getParameter("pmodel");
		String price =request.getParameter("price");
		 UserDao dao=new UserDao();
		 int na=dao.editdetails(pid,productname,productmodel,price);
		 if(na>0)
		 {
			// response.sendRedirect("login.jsp");
			 RequestDispatcher rd= request.getRequestDispatcher("view_all.jsp");
			 rd.forward(request, response);
		 }
		 else
		 {
		 
			 RequestDispatcher rd= request.getRequestDispatcher("edit.jsp");
					 rd.include(request, response);
		 
	}		
	}

}
