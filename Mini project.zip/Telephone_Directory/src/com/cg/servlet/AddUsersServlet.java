package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.Admindao;


/**
 * Servlet implementation class AddUsersServlet
 */
@WebServlet("/AddUsersServlet")
public class AddUsersServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username =request.getParameter("name");
		String useraddress=request.getParameter("address");
		String usermobileno=request.getParameter("mobile");
		String userstate=request.getParameter("state");
		 Admindao dao=new Admindao();
		 int na=dao.addusers(username,useraddress,usermobileno,userstate);
		 if(na>0)
		 {
			 response.sendRedirect("Viewall.jsp");
			// RequestDispatcher rd= request.getRequestDispatcher("viewall.jsp");
			 //rd.forward(request, response);
		 }
		 else
		 {
		 
			 RequestDispatcher rd= request.getRequestDispatcher("addusers.jsp");
					 rd.include(request, response);
		 
	}
	}

}
