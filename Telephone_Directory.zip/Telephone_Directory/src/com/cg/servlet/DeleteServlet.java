package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.Admindao;
;

/**
 * Servlet implementation class DeleteServlet
 */
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String mobilenumber=request.getParameter("mobile");
		Admindao dao=new Admindao();
		 int na=dao.deletedetails(mobilenumber);
		 if(na>0)
		 {
			
			 RequestDispatcher rd= request.getRequestDispatcher("view_all.jsp");
			 rd.forward(request, response);
		 }
		 else
		 {
		 
			 RequestDispatcher rd= request.getRequestDispatcher("edit.jsp");
					 rd.include(request, response);
		 
	}
	}

}
