package com.cg.servlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Admindao {

	Connection con=null;
	PreparedStatement ps =null;
	ResultSet rs=null;
 public Connection getConnection()
 {
	 try{
		 Class.forName("oracle.jdbc.driver.OracleDriver");
		 String url= "jdbc:oracle:thin:@localhost:1521:XE";
		 String user = "system";
		 String pass ="Capgemini123";
		 con = DriverManager.getConnection(url,user,pass);
		 return con;
				 }catch(Exception e)
	 {
					 e.printStackTrace();
						
	 }return con;
 }	
	 public boolean validateuser(String username, String password) 
	{
		try{
		con=getConnection();
		
		String sql ="select * from admin where username=? and password=?";
		
		ps=con.prepareStatement(sql);
		
		ps.setString(1, username);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
         return rs.next();
	}catch(Exception e){
		e.printStackTrace();
		return false;
	}
}
	 
	 public int password(String username,String password,String confpassword){
 try{		
			 
			 if(password.equals(confpassword))
			{
				
			  con =getConnection();
			  String sql="update admin SET PASSWORD=? WHERE USERNAME=?";
				  ps=con.prepareStatement(sql);
				  ps.setString(1,password);
				  ps.setString(2,username);
				  ps.executeUpdate();
				  return 1;
			 
			  }
		 }catch(Exception e) {
			  e.printStackTrace();
			 
			
} return 0;
	}
	public int addusers(String username, String useraddress,String usermobileno, String userstate) {
		try{
			  con =getConnection();
			  
			  String sql="insert into users values(?,?,?,?)";
				  ps=con.prepareStatement(sql);
				  ps.setString(1, username);
				  ps.setString(2, useraddress);
				  ps.setString(3, usermobileno);
				  ps.setString(4,userstate);
				  int n =ps.executeUpdate();
				  return n;
			  }catch(Exception e) {
				  e.printStackTrace();
				  
			  }
		return 0;
	}
	public int editdetails(String username, String useraddress,
			String usermobile, String userstate) {
		try{
			System.out.println(username);
		 con=getConnection();
		 String sql="update users set name=?,address=?,state=? where mobile=?";
		 ps=con.prepareStatement(sql);
		  ps.setString(1, username);
		  ps.setString(2, useraddress);
		  ps.setString(3, userstate);
		  ps.setString(4, usermobile);
		  int n =ps.executeUpdate();
		  System.out.println(n);
		  return n;	
	}catch(Exception e)
		{
		return 0;
		}
}
	public int deletedetails(String mobilenumber) {
		try{
			  con =getConnection();
			  String sql="delete from users where mobile=?";
				  ps=con.prepareStatement(sql);
				  ps.setString(1,mobilenumber);
				  int n =ps.executeUpdate();
				  return n;
			  }catch(Exception e) {
				  e.printStackTrace();
				  return 0;
			  }
			

	}
}
